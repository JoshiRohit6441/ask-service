import mongoose from "mongoose";

const contactSchema = new mongoose.Schema(
  {
    first_name: { type: String, required: true, trim: true },
    last_name: { type: String, required: true, trim: true },
    client_type: {
      type: String,
      enum: ["Individual", "Company"],
      default: "Individual",
    },
    phone: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true },
  },
  { _id: false },
);

const ServiceRequestSchema = new mongoose.Schema(
  {
    reference_no: { type: String, required: true, unique: true },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    service_category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceCategory",
      required: true,
    },
    child_category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceCategory",
      default: null,
    },
    manual_child_category: { type: String, default: null, trim: true },
    frequency: {
      type: String,
      enum: ["One-time service", "Daily", "Weekly", "Bi-weekly", "Monthly"],
      required: true,
    },
    selected_options: [
      {
        type: String,
        trim: true,
      },
    ],
    preferred_start_date: {
      type: Date,
      default: null,
    },
    preferred_time_of_day: {
      type: String,
      default: null,
      trim: true,
    },
    note: {
      type: String,
      default: null,
      trim: true,
    },
    address_1: {
      type: String,
      required: true,
      trim: true,
    },
    address_2: {
      type: String,
      trim: true,
    },
    city: {
      type: String,
      required: true,
      trim: true,
    },
    state: {
      type: String,
      required: true,
      trim: true,
    },
    country: {
      type: String,
      required: true,
      trim: true,
    },
    pincode: {
      type: String,
      default: null,
      trim: true,
    },
    status: {
      type: String,
      enum: ["ACTIVE", "CANCELLED", "EXPIRED"],
      default: "ACTIVE",
    },
    contact_details: { type: contactSchema, required: true },
    deletedAt: { type: Date, default: null },
    reason: {
      type: String,
      default: null,
    },
  },
  { timestamps: true },
);

ServiceRequestSchema.index({ user: 1, createdAt: -1 });
ServiceRequestSchema.index({ service_category: 1, status: 1 });

const ServiceRequest = mongoose.model("ServiceRequest", ServiceRequestSchema);

export default ServiceRequest;
